<?php 
try {  
	require 'DB_Manage.php';   
	  
	 $User = $_REQUEST["User"];  
	 $Password = $_REQUEST["Password"];
	$clientNumber = $_REQUEST["clientNumber"];
	
	 $sql = "INSERT INTO `Login`( `User`, `Password`,`clientNumber`) 
	 VALUES ('$User', '$Password','$clientNumber')";    
	 if ($conn->query($sql) === TRUE) {   
		 $last_id = $conn->insert_id;   
		 echo $User;  
	 }  
	 else {   echo "Error: " . $sql . "\n" . $conn->error; 
		  } 
	}  
catch(Exception $e) {  echo "Exception Error See Log....";  
					 error_log($e->getMessage() , 0); 
					}  
$conn->close(); 
?> 