<?php 
try {  
	require 'DB_Manage.php';   
	 
	 $_id = $_REQUEST["_id"];
	 $firstName = $_REQUEST["firstName"];  
	 $lastName = $_REQUEST["lastName"];  
	 $phoneNumber = $_REQUEST["phoneNumber"]; 
	 $mail = $_REQUEST["mail"];  
	 $cardNumber = $_REQUEST["cardNumber"]; 
	 $sql = "INSERT INTO `client_table`( `_id`, `firstName`,`lastName`,`phoneNumber`,`mail`,`cardNumber`) 
	 VALUES ('$_id', '$firstName', '$lastName', '$phoneNumber', '$mail', '$cardNumber')";    
	 if ($conn->query($sql) === TRUE) {   
		 $last_id = $conn->insert_id;   
		 echo $last_id;  
	 }  
	 else {   echo "Error: " . $sql . "\n" . $conn->error; 
		  } 
	}  
catch(Exception $e) {  echo "Exception Error See Log....";  
					 error_log($e->getMessage() , 0); 
					}  
$conn->close(); 
?> 