<?php 
try {  
	require 'DB_Manage.php';   
	 if (isset($_REQUEST["branchNumber"])) 
		$branchNumber = $_REQUEST["branchNumber"];
	else 
		$branchNumber = 'NULL'; 
	  
	 $parking_spaces = $_REQUEST["parking_spaces"];  
	 $city = $_REQUEST["city"];  
	 $street = $_REQUEST["street"]; 
	 $number = $_REQUEST["number"];  
	 $sql = "INSERT INTO `branch_table`( `branchNumber`, `parking_spaces`,`city`,`street`,`number`) 
	 VALUES ('$branchNumber', '$parking_spaces', '$city', '$street', '$number')";    
	 if ($conn->query($sql) === TRUE) {   
		 $last_id = $conn->insert_id;   
		 echo $last_id;  
	 }  
	 else {   echo "Error: " . $sql . "\n" . $conn->error; 
		  } 
	}  
catch(Exception $e) {  echo "Exception Error See Log....";  
					 error_log($e->getMessage() , 0); 
					}  
$conn->close(); 
?> 