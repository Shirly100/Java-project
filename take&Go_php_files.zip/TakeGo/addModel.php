<?php 
try {  
	require 'DB_Manage.php';
	 if (isset($_REQUEST["modelCode"])) 
		$modelCode = $_REQUEST["modelCode"];
	else 
		$modelCode = 'NULL'; 
	
	 $company = $_REQUEST["company"];  
	 $modelName = $_REQUEST["modelName"];  
	 $EngineCapacity = $_REQUEST["EngineCapacity"]; 
	 $gear = $_REQUEST["gear"];  
	 $SeatingCapacity = $_REQUEST["SeatingCapacity"]; 
	$DoorsNumber = $_REQUEST["DoorsNumber"]; 
	$emptyMass = $_REQUEST["emptyMass"]; 
	$fuel = $_REQUEST["fuel"]; 
	$engine_type = $_REQUEST["engine_type"]; 
	$turbo = $_REQUEST["turbo"]; 
	$Lighted_makeup_mirror = $_REQUEST["Lighted_makeup_mirror"]; 
	$Digital_radio = $_REQUEST["Digital_radio"]; 
	$Panorama = $_REQUEST["Panorama"];
	$Driver_airbag = $_REQUEST["Driver_airbag"]; 
	$Emergency_brake_assist = $_REQUEST["Emergency_brake_assist"]; 
	$Total_max_power = $_REQUEST["Total_max_power"];
	 $sql = "INSERT INTO `carModel_table`( `modelCode`, `company`,`modelName`,`EngineCapacity`,`gear`,`SeatingCapacity`,`DoorsNumber`,`emptyMass`,`fuel`,`engine_type`,`turbo`,`Lighted_makeup_mirror`,`Digital_radio`,`Panorama`,`Driver_airbag`,`Emergency_brake_assist`,`Total_max_power`) 
	 VALUES ('$modelCode', '$company', '$modelName', '$EngineCapacity', '$gear', '$SeatingCapacity','$DoorsNumber','$emptyMass','$fuel','$engine_type','$turbo','$Lighted_makeup_mirror','$Digital_radio','$Panorama','$Driver_airbag','$Emergency_brake_assist','$Total_max_power')";    
	 if ($conn->query($sql) === TRUE) {   
		 $last_id = $conn->insert_id;   
		 echo $modelCode;  
	 }  
	 else {   echo "Error: " . $sql . "\n" . $conn->error; 
		  } 
	}  
catch(Exception $e) {  echo "Exception Error See Log....";  
					 error_log($e->getMessage() , 0); 
					}  
$conn->close(); 
?> 