<?php 
try {  
	require 'DB_Manage.php';   
	 
	$orderNumber = $_REQUEST["orderNumber"]; 
	 $order = $_REQUEST["order"];  
	 $rental_end_date = $_REQUEST["rental_end_date"]; 
	$mileage_end_value = $_REQUEST["mileage_end_value"]; 
	$fuel_filling = $_REQUEST["fuel_filling"]; 
	$quantity_of_fuel = $_REQUEST["quantity_of_fuel"]; 
	$payment = $_REQUEST["payment"];
	
	  $sql = "UPDATE `order_table`  SET  `order`= '$order',  `rental_end_date`='$rental_end_date',  `mileage_end_value`='$mileage_end_value',  `fuel_filling`='$fuel_filling',  `quantity_of_fuel`='$quantity_of_fuel',  `payment`='$payment' 
WHERE `orderNumber`='$orderNumber'";  
	
	   
	 if ($conn->query($sql) === TRUE) {    
		 echo "order is closed";  
	 }  
	 else {   echo "Error: " . $sql . "\n" . $conn->error; 
		  } 
	}  
catch(Exception $e) {  echo "Exception Error See Log....";  
					 error_log($e->getMessage() , 0); 
					}  
$conn->close(); 
?> 