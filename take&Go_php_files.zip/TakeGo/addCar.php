<?php 
try {  
	require 'DB_Manage.php';   
	 if (isset($_REQUEST["carNumber"])) 
		$carNumber = $_REQUEST["carNumber"];
	else 
		$carNumber = 'NULL'; 
	  
	 $branchNumber = $_REQUEST["branchNumber"];  
	 $modelType = $_REQUEST["modelType"];  
	 $mileage = $_REQUEST["mileage"]; 
	$occupied = $_REQUEST["occupied"]; 
	 $sql = "INSERT INTO `car_table`( `carNumber`, `branchNumber`,`modelType`,`mileage`,`occupied`) 
	 VALUES ('$carNumber', '$branchNumber', '$modelType', '$mileage','$occupied')";    
	 if ($conn->query($sql) === TRUE) {   
		 $last_id = $conn->insert_id;   
		 echo $last_id;  
	 }  
	 else {   echo "Error: " . $sql . "\n" . $conn->error; 
		  } 
	}  
catch(Exception $e) {  echo "Exception Error See Log....";  
					 error_log($e->getMessage() , 0); 
					}  
$conn->close(); 
?> 