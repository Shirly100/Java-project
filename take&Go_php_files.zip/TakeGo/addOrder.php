<?php 
try {  
	require 'DB_Manage.php';   
	 if (isset($_REQUEST["orderNumber"])) 
		$orderNumber = $_REQUEST["orderNumber"];
	else 
		$orderNumber = 'NULL'; 
	  
	 $clientNumber = $_REQUEST["clientNumber"];  
	 $order = $_REQUEST["order"];  
	 $carNumber = $_REQUEST["carNumber"]; 
	$rental_srart_date = $_REQUEST["rental_srart_date"];	
	 $rental_end_date = $_REQUEST["rental_end_date"]; 
	$mileage_start_value = $_REQUEST["mileage_start_value"]; 
	$mileage_end_value = $_REQUEST["mileage_end_value"]; 
	$fuel_filling = $_REQUEST["fuel_filling"]; 
	$quantity_of_fuel = $_REQUEST["quantity_of_fuel"]; 
	$payment = $_REQUEST["payment"]; 
	 $sql = "INSERT INTO `order_table`( `orderNumber`, `clientNumber`,`order`,`carNumber`,`rental_srart_date`,`rental_end_date`,`mileage_start_value`,`mileage_end_value`,`fuel_filling`,`quantity_of_fuel`,`payment`) 
	 VALUES ('$orderNumber', '$clientNumber', '$order', '$carNumber', '$rental_srart_date', '$rental_end_date', '$mileage_start_value', '$mileage_end_value', '$fuel_filling', '$quantity_of_fuel', '$payment')";    
	 if ($conn->query($sql) === TRUE) {   
		 $last_id = $conn->insert_id;   
		 echo $last_id;  
	 }  
	 else {   echo "Error: " . $sql . "\n" . $conn->error; 
		  } 
	}  
catch(Exception $e) {  echo "Exception Error See Log....";  
					 error_log($e->getMessage() , 0); 
					}  
$conn->close(); 
?> 
