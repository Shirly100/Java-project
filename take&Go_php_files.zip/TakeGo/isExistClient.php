<?php
try{
	 require 'DB_Manage.php';   
	 $_id = $_REQUEST["_id"];
	 $firstName = $_REQUEST["firstName"];  
	 $lastName = $_REQUEST["lastName"];  
	 $phoneNumber = $_REQUEST["phoneNumber"]; 
	 $mail = $_REQUEST["mail"];  
	 $cardNumber = $_REQUEST["cardNumber"]; 
     $sql = "SELECT _id FROM `client_table` WHERE `_id`='$_id'";
	 $result = $conn->query($sql);

	 if ($result->num_rows > 0) 
	 {
		 echo 'ShoSHI';
	 }
    /*if(mysql_num_rows($result))
	{
		echo "YES";
	} 
	else 
	{
		echo "NO";
   }*/
	
}
catch(Exception $e) {  
	echo "Exception Error See Log....";  
	error_log($e->getMessage() , 0); 
}  
$conn->close(); 
?>