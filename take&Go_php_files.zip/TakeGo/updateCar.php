<?php
try{
	
	 require 'DB_Manage.php';
	 $carNumber = $_REQUEST["carNumber"];
	 $branchNumber = $_REQUEST["branchNumber"];  
	 $modelType = $_REQUEST["modelType"];  
	 $mileage = $_REQUEST["mileage"]; 
	$occupied = $_REQUEST["occupied"]; 

     $sql = "UPDATE `car_table`  SET occupied = 'YES'  WHERE `carNumber`='$carNumber'"; 
	  
	 

	if ($conn->query($sql) === TRUE) {   
		 echo "The car is now occupied" ; 
	 }

	
}
catch(Exception $e) {  
	echo "Exception Error See Log....";  
	error_log($e->getMessage() , 0); 
}  
$conn->close(); 
?>